class Profile{
  final String url;
  final String name;

  Profile({required this.url, required this.name,});
}