package com.example.flutter_application_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
